import React from 'react';

function App() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-black text-white">
      <h1 className="text-4xl font-bold text-neon mb-4">Abhisave</h1>
      <p className="text-lg">Download Shorts, Reels & TikToks!</p>
    </div>
  );
}

export default App;